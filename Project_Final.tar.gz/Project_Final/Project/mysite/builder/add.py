def add(list_ingredients):
    word = ""
    for i in list_ingredients:
        word += i
    return word
