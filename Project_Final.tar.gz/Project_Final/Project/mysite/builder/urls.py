from django.conf.urls import url
from django import http
from . import views

'''
This file contains the URL links to the three views that our Project
has. They are the Search page, Results page, and About page.
'''

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^results/$', views.results, name='results'),
    url(r'^about/$', views.about, name='about')
]





