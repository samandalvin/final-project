from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.core.urlresolvers import reverse
from django import forms
from django.forms import ModelForm
from .models import Recipe
import sys

sys.path.insert(0,"../..")

from ignore_query import go
'''
This file contains the three view pages that our website has.
'''

def index(request):
	return render(request, 'builder/index.html')

def about(request):
	return render(request, 'builder/about.html')

def results(request):
	'''
	This function takes the string of search terms entered by the user,
	converts it into a list, and calls go(), which extracts a list of recipes
	that use as many of the ingredients provided.

	We used a For loop to create a Recipe class for every recipe in the list.
	A series of conditionals deals with ingredients that the user lacks, but the
	recipe uses.
	'''
	ingredients = request.GET.get('ingredients')
	list_ingredients = ingredients.split(',')
	list_results = go(list_ingredients)
	list_recipes = []

	if len(list_results) == 0: #if no search results
		return render(request, 'builder/noresults.html')
	
	for result in list_results:
		for url in result:
			current_recipe = Recipe(recipe_url = url, 
				recipe_name = result[url]["title"], 
				recipe_image = result[url]["food_img_url"], 
				ingredients_used = result[url]["ingredients_possessed"],
				ratings = result[url]["rating"], 
				cook_time = result[url]["cook_time"], 
				prep_time = result[url]["prep_time"])
			if result[url]["number_missing"] != 0: 
			#if the user is missing ingredients
				current_recipe.missing = list(result[url]["missing"].keys())[0]
				if result[url]["missing"][current_recipe.missing] == {}: 
				#if Instacart doesn't have these ingredients
					ingredient_name = current_recipe.missing
					current_recipe.missing_price = "This is not in stock, sorry"
				else:
					ingredient_name = list(result[url]["missing"]
						[current_recipe.missing].keys())[0]
					current_recipe.missing_price = result[url]["missing"][current_recipe.missing][ingredient_name]['price']
			else: #user has all the necessary ingredients
				current_recipe.missing = "Nothing"
				current_recipe.missing_price = "You don't have spend $"
			list_recipes.append(current_recipe)
	context = {'list_recipes':list_recipes}
	return render(request, 'builder/results.html', context)

