from django.db import models

'''
This file contains two simple models that we used for the Project.
The Recipe class is used to assign information to the different
variables associated with each Recipe.

'''

class Ingredient(models.Model):
	ingredient_text = models.CharField(max_length=100)

	def __str__(self):
		return self.ingredient_text

class Recipe(models.Model):
    recipe_url = models.CharField(max_length=300)
    recipe_name = models.CharField(max_length=300)
    cook_time = models.IntegerField()
    prep_time = models.IntegerField()
    recipe_image = models.CharField(max_length=300)
    ingredients_used = models.CharField(max_length=300)
    missing = models.CharField(max_length=300)
    missing_price = models.CharField(max_length=300)
    ratings = models.CharField(max_length=300)






