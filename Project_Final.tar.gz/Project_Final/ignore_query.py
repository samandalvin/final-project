import sqlite3
import json
import instacart
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INGREDIENTS_DATABASE_FILENAME = os.path.join(SCRIPT_DIR, 'ignore_ingredients.db')
DETAILS_DATABASE_FILENAME = os.path.join(SCRIPT_DIR, 'ignore_details.db')
RECIPES_JSON_FILE = os.path.join(SCRIPT_DIR, 'ignore_dictionary_of_recipe_links.json')
#TOLERANCE is the maximum number of missing ingredients per recipe we will allow
TOLERANCE = 1

def import_json_to_dictionary(filename):
    '''
    Takes a json file and returns a dictionary.
    '''
    with open(filename) as f:
        d = json.load(f)
    return d

def get_candidate_recipes(user_ingredients):
    '''
    Helper function for get_all_final_recipes().
    Takes in the user's ingredients and returns recipes which use the ingredients.
    Inputs:
        user_ingredients: list of ingredients user provides
    Returns:
        A dictionary where key is recipe url, value is list of recipe's 
        ingredients user possesses
    '''
    conn_ingredients = sqlite3.connect(INGREDIENTS_DATABASE_FILENAME)
    c_ingredients = conn_ingredients.cursor()
    candidate_recipes = {}
    for ingredient in user_ingredients:
        sqlite_object = c_ingredients.execute("SELECT * FROM data WHERE ingredient LIKE '%{}%'".
            format(ingredient))
        list_of_ingredients = sqlite_object.fetchall()
        if list_of_ingredients == []: #if none of the recipes use stated ingredient
            continue
        for ingredient, link in list_of_ingredients:
            candidate_recipes[link] = candidate_recipes.get(link, [])
            candidate_recipes[link].append(ingredient) #value is list of ingredients that we have
    conn_ingredients.close()
    return candidate_recipes

def get_all_final_recipes(user_ingredients, dictionary_of_recipes, tolerance):
    '''
    Takes in user ingredients and returns recipes where user has less than 'tolerance'
    nummber of ingredient missing.
    Inputs:
        user_ingredients: list of ingredients user has
        dictionary_of_recipes: dictionary of recipes where key is recipe url and value 
        is list of ingredients
    Returns:
        A dictionary where key is recipe link, and values are missing_ingredients 
        and ingredients_possessed possessed
    '''
    candidate_recipes = get_candidate_recipes(user_ingredients)
    all_final_recipes = {}
    for candidate, ingredients in candidate_recipes.items():
        all_ingredients = set(dictionary_of_recipes[candidate])
        ingredients_possessed = set(ingredients)
        if len(all_ingredients) - len(ingredients_possessed) <= tolerance: 
            all_ingredients.difference_update(ingredients_possessed) #missing ingredients
            all_final_recipes[len(ingredients)] = all_final_recipes.get(len(ingredients), {})
            all_final_recipes[len(ingredients)][candidate] = {}
            all_final_recipes[len(ingredients)][candidate]["missing_ingredients"] = list(all_ingredients)
            all_final_recipes[len(ingredients)][candidate]["ingredients_possessed"] = ingredients
    return all_final_recipes

def find_instacart_details(link, missing_ingredient_list, instacart_session, rv_dict):
    '''
    Helper function for add_links_to_dictionary().
    Takes in the missing_ingredient_list and populates rv_dict with the 
    necessary information on the missing ingredients.
    '''
    for ingredient in missing_ingredient_list:
        missing_ingredient_dictionary = instacart.get_missing_ingredient_details(
            instacart_session, ingredient)
        rv_dict[link]["missing"][ingredient] = missing_ingredient_dictionary #{} if instacart does not have

def sort_by_ratings(ratings_list, ranking_list):
    '''
    Helper function for add_links_to_dictionary().
    Sorts recipes within each group (with same number of the user's 
    ingredients we use) by ratings, and adds the sorted order to the
    final ranking list.
    '''
    ratings_list.sort()
    ratings_list.reverse()
    ranking_list.extend(ratings_list)

def add_links_to_dictionary(dict_n_possessed, c_details, instacart_session, rv_dict, ranking_list):
    '''
    Adds recipe details to a dictionary.
    Inputs:
        dict_n_possessed: dictionary that uses n number of usuer ingredients
        c_details: sqlite cursor object of database file containing recipe details
        instacart_session: logged-in python requests object
        rv_dict: dictionary containing recipe details of the recipes we are 
                 going to display
        ranking_list: list containing the order of display on our website
    '''
    ratings_list = []
    for link in dict_n_possessed.keys():
        missing_ingredient_list = dict_n_possessed[link]["missing_ingredients"]
        ingredients_possessed = dict_n_possessed[link]["ingredients_possessed"]
        sqlite_object = c_details.execute('SELECT title, rating, prep time, cook time, image FROM data WHERE recipe = "{}"'.
            format(link))
        title, rating, prep_time, cook_time, image_url = sqlite_object.fetchall()[0]
        rv_dict[link] = {}
        rv_dict[link]["title"] = title
        rv_dict[link]["rating"] = rating
        rv_dict[link]["prep_time"] = prep_time
        rv_dict[link]["cook_time"] = cook_time
        rv_dict[link]["food_img_url"] = image_url
        rv_dict[link]["number_missing"] = len(missing_ingredient_list)
        rv_dict[link]["ingredients_possessed"] = ingredients_possessed
        rv_dict[link]["missing"] = {}
        ratings_list.append((rating, link))
        if missing_ingredient_list == []:
            continue
        else:
            find_instacart_details(link, missing_ingredient_list, 
                instacart_session, rv_dict)
    return ratings_list

def output_to_sorted_list(ranking_list, rv_dict):
    '''
    Takes in the dictionary containing the details of the
    recipes we are going to display, and outputs to a list in the order
    specified by ranking_list.
    '''
    rv_list = []
    for rating, link in ranking_list:
        d = {}
        d[link] = rv_dict[link]
        rv_list.append(d)
    return rv_list

def rank_by_ingredients_used_then_by_rating(all_final_recipes, ranking_list, c_details, instacart_session, rv_dict):
    '''
    Ranks recipes first by number of user ingredients consumed, 
    then by recipe's rating.
    '''
    for n in reversed(sorted(list(all_final_recipes.keys()))):
        dict_n_possessed = all_final_recipes[n]
        ratings_list = add_links_to_dictionary(dict_n_possessed, 
            c_details, instacart_session, rv_dict, ranking_list)
        sort_by_ratings(ratings_list, ranking_list)

def refine_user_ingredients(list_ingredients):
    '''
    Strips off white spaces and changes case of user's ingredients.
    '''
    refined_list = []
    for ingredient in list_ingredients:
        ingredient = ingredient.lower()
        ingredient = ingredient.strip()
        refined_list.append(ingredient)
    return refined_list

def go(list_ingredients):
    '''
    Calls in order all the functions above, to return a ranked list of dictionaries containing
    recipe details to be passed over to Django.
    '''
    ranking_list = []
    rv_dict = {}
    dictionary_of_recipes = import_json_to_dictionary(RECIPES_JSON_FILE)
    user_ingredients = refine_user_ingredients(list_ingredients)
    if user_ingredients == ['']:
        return []
    all_final_recipes = get_all_final_recipes(user_ingredients, 
        dictionary_of_recipes, TOLERANCE)
    instacart_session = instacart.login()
    conn_details = sqlite3.connect(DETAILS_DATABASE_FILENAME)
    c_details = conn_details.cursor()
    rank_by_ingredients_used_then_by_rating(all_final_recipes, 
        ranking_list, c_details, instacart_session, rv_dict)
    conn_details.close()
    instacart_session.close()
    rv_list = output_to_sorted_list(ranking_list, rv_dict)
    return rv_list