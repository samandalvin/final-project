import json
import sqlite3
import sys

INGREDIENTS_DATABASE_FILENAME = 'ignore_ingredients.db'
INGREDIENTS_JSON_FILE = 'ignore_dictionary_of_ingredients.json'
DETAILS_DATABASE_FILENAME = 'ignore_details.db'
DETAILS_JSON_FILE = 'ignore_dictionary_of_details.json'

def import_json_to_dictionary(filename):
    '''
    Imports a json file to a dictionary.
    '''
    with open(filename) as f:
        d = json.load(f)
    return d

def create_ingredients_database(data_filename, json_filename):
    '''
    Creates a sql database for ingredients.
    '''
    dictionary_of_ingredients = import_json_to_dictionary(json_filename)
    conn = sqlite3.connect(data_filename)
    c = conn.cursor()
    c.execute('CREATE TABLE data (ingredient text, recipe_link text)')

    for ingredient, list_of_recipe_links in dictionary_of_ingredients.items():
        for recipe in list_of_recipe_links:
            insertion = [ingredient, recipe]
            c.execute("INSERT INTO data VALUES (?, ?)", insertion)
    conn.commit()
    conn.close()

def create_details_database(data_filename, json_filename):
    '''
    Creats a sql database for recipe details.
    '''
    dictionary_of_recipes = import_json_to_dictionary(json_filename)
    conn = sqlite3.connect(data_filename)
    c = conn.cursor()
    c.execute('CREATE TABLE data (recipe text, title text, rating real, prep time int, cook time int, image text)')

    for recipe_link, dictionary_of_details in dictionary_of_recipes.items():
        title = dictionary_of_details["title"]
        rating = dictionary_of_details["rating"]
        prep_time = dictionary_of_details["prep_time"]
        cook_time = dictionary_of_details["cook_time"]
        image = dictionary_of_details["image"]
        insertion = [recipe_link, title, rating, prep_time, cook_time, image]
        c.execute("INSERT INTO data VALUES (?, ?, ?, ?, ?, ?)", insertion)
    conn.commit()
    conn.close()

if __name__=="__main__":
    num_args = len(sys.argv)
    if num_args != 2:
        print("usage: python3 " + sys.argv[0] + " ingredients or details")
        sys.exit(0)

    elif sys.argv[1] == "ingredients":
        create_ingredients_database(INGREDIENTS_DATABASE_FILENAME, 
            INGREDIENTS_JSON_FILE)

    elif sys.argv[1] == "details":
        create_details_database(DETAILS_DATABASE_FILENAME, 
            DETAILS_JSON_FILE)