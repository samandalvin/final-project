import requests
import re
import bs4
import json

def login():
    '''
    Logs into instacart with Alvin's account.
    '''
    s = requests.Session()
    r = s.get('https://www.instacart.com/#login')
    bs = bs4.BeautifulSoup(r.text, 'html5lib')
    meta_tags = bs.find_all('meta')
    for meta in meta_tags:
        if meta.has_attr('name'):
            if meta['name'] == 'csrf-token':
                auth_token = meta['content']
    payload = {'user[email]': 'leeziyang@uchicago.edu', 
    'user[password]': 'Hellosam123', 
    'authenticity_token': auth_token}
    s.post('https://www.instacart.com/accounts/login', data = payload)
    return s

def get_missing_ingredient_details(s, ingredient):
    '''
    Takes an ingredient and looks it up on instacart.
    Returns a dictionary with the details of the first search result, if any.
    Note that we have assumed location is Hyde Park, and searched
    only Jewel-Osco, as Instacart makes us choose a store and location.
    '''
    rv = {}
    params = '+'.join(ingredient.split())
    page = s.get('https://www.instacart.com/api/v2/searches?term={}&page=1&per=100&disable_autocorrect=false&source=web&warehouse_id=10&zone_id=28'.format(params))
    data = json.loads(page.text) #page.text is simply a json databse
    items = data['data']['items']
    for item in items:
        display_name = item['display_name']
        full_price = '$' + str(item['full_price'])
        unit = item['display_size']
        image_url = item['primary_image_url']
        rv[display_name] = {} #instacart's display name of the ingredient
        rv[display_name]['price'] = full_price
        rv[display_name]['unit'] = unit #weight of the product for the display price
        rv[display_name]['instacart_img_url'] = image_url #image url of the product
        break #to get only first search result
    return rv #will return empty dict if no results
    #{'Red Bell Peppers': {'price': '$0.69', 'unit': 'per lb', 'image_url': 'https://d2lnr5mha7bycj.cloudfront.net/product-image/file/primary_52b25837-dfe1-4492-bd7d-1b441e3ee427.jpg'}}


