import bs4
import re
import requests
import json

DICTIONARY_OF_INGREDIENTS_FILENAME = 'ignore_dictionary_of_ingredients.json'
DICTIONARY_OF_RECIPE_LINKS_FILENAME = 'ignore_dictionary_of_recipe_links.json'
DICTIONARY_OF_DETAILS_FILENAME = 'ignore_dictionary_of_details.json'
HTML_ENCODING_FILE = 'html_encoding.txt'
NUMBER_OF_PAGES_TO_INDEX = 260
#These are ingredients we assume user to have by default.
INGREDIENTS_TO_IGNORE = ["oil", "sugar", "salt", "water", "black pepper", "white pepper", "cayenne pepper",
"vinegar", "butter", "cornstarch", "soy sauce", "hot sauce", "ketchup"]

def output_to_json_file(d, filename):
    '''
    Takes a dictionary and outputs it to a json file.
    '''
    with open(filename, 'w') as f:
        json.dump(d, f)

def generate_html_encoding_dictionary(filename):
    '''
    Takes in a file containing UTF-8 encoding and outputs a dictionary
    mapping UTF-8 encodings to human-readable characters.
    '''
    rv = {}
    with open(filename, 'r') as f:
        for line in f:
            values = line.split()
            if values[0] == 'space':
                values[0] = ' '
            try:
                rv[values[1].lower()] = values[0]
            except IndexError:
                #Some obscure characters cannot be read in the text file 
                #and appear as empty spaces. We skip these. 
                continue
    return rv

def convert_encoding(string, dictionary_of_html_encoding):
    '''
    Analyzes a string for UTF-8 encoding. If present, converts to human-readable
    characters. Else, leaves it untouched.
    '''
    if string.count('%') == 0:
        pass
    else:
        count = string.count('%')
        for i in range(count):
            index = string.find('%')
            encoding = string[index:index+3]
            try:
                string = string.replace(encoding, 
                    dictionary_of_html_encoding[encoding])
            except KeyError:
                #Means the '%' was deliberate and not UTF-8 encoding.
                pass
    return string


def find_recipe_links_one_page(request):
    '''
    Takes in a request object and scans the webpage for recipe links.
    Returns a list of relative urls linking to recipe pages.
    '''
    html = request.text
    recipe_links = re.findall(r'"record_spec":"(Recipe\-[0-9]+)"', html) #['Recipe-45809', 'Recipe-27208', 'Recipe-89204', 'Recipe-39087', 'Recipe-32204', 'Recipe-67256', 'Recipe-22782', 'Recipe-54257', 'Recipe-35813', 'Recipe-420398']
    return recipe_links

def add_links_to_set(recipe_links, current_set):
    '''
    Takes in a list of recipe links and adds it into to a specified set.
    '''
    for link in recipe_links:
        current_set.add(link)
        print ('{}...'.format(link))

def find_recipe_links_all_pages(number_to_index, base_url = 'http://www.food.com/recipe/all/popular'):
    '''
    Crawls through the specified number of "most popular recipes" pages on Food.com
    to exctract all the recipe links.
    Inputs
        number_to_index: number of pages to index
        base_url: base url of the most popular food pages
    Returns:
        A set of the most popular recipe links on Food.com
    '''
    set_of_recipe_links = set([])
    print ('`````` BEGIN RECIPES TO BE INDEXED````````')
    for n in range(1, number_to_index + 1):
        prms = {'pn': n}
        r = requests.get(base_url, params = prms)
        links = find_recipe_links_one_page(r)
        add_links_to_set(links, set_of_recipe_links)
    print ('`````NUMBER OF RECIPES INDEXED: {}`````'.format(len(set_of_recipe_links)))
    return set_of_recipe_links

def index_one_recipe_page(dictionary_of_ingredients, dictionary_of_recipe_links, dictionary_of_details, dictionary_of_html_encoding, link, base_url = 'http://www.food.com/'):
    '''
    Helper function for index_all_recipe_pages().
    Extracts all relevant information from a given recipe page,
    Inputs:
        dictionary_of_ingredients: key = ingredients, value = list of recipes using that ingredient
        dictionary_of_recipe_links: key = recipe url, value = list of ingredients the recipe uses
        dictionary_of_details: key = recipe url, value = dictionary containing title, rating, time, and food image url
        dictionary_of_html_encoding: dictionary mapping UTF-8 encodings to human-readable characters
        link: relative link of recipe page
        base_url: url for relative url to be appended to
    '''
    r = requests.get('{}{}'.format(base_url, link))
    print('{}...'.format(r.url))
    s = bs4.BeautifulSoup(r.text, 'html5lib')
    recipe_details = s.find('div', class_ = 'recipe-detail')
    if recipe_details != None: #some recipes are private .e.g. http://www.food.com/recipe/your-kids-time-out-lunch-39936
        ingredient_list = extract_ingredients(recipe_details, dictionary_of_html_encoding)
        for ingredient in ingredient_list:
            dictionary_of_ingredients[ingredient] = dictionary_of_ingredients.get(ingredient, [])
            dictionary_of_ingredients[ingredient].append(r.url)
        dictionary_of_recipe_links[r.url] = ingredient_list
        title, rating = extract_title_and_rating(s)
        time = extract_time(recipe_details)
        image = extract_image(s)
        dictionary_of_details[r.url] = dictionary_of_details.get(r.url, {})
        dictionary_of_details[r.url]["title"] = title
        dictionary_of_details[r.url]["rating"] = rating
        dictionary_of_details[r.url]["prep_time"] = time[0]
        dictionary_of_details[r.url]["cook_time"] = time[1]
        dictionary_of_details[r.url]["image"] = image

def extract_ingredients(recipe_details, dictionary_of_html_encoding):
    '''
    Helper function for index_one_recipe_page().
    Takes in a BeautifulSoup object and returns the a list of ingredients
    the recipe uses.
    '''
    ingredient_details = recipe_details.find('div', class_ = 'ingredients')
    ingredient_list_detailed = ingredient_details.find_all('li')
    recipe_ingredients = set([])
    for i in ingredient_list_detailed: # <li data-ingredient="boneless+chicken+breasts"><span>2 </span> lbs  <a href="http://www.food.com/about/chicken-221">boneless chicken breasts</a>, cut into bite-size pieces</li>
        if i.has_attr('data-ingredient'):
            ingredient_name = " ".join(i['data-ingredient'].split('+'))
            ingredient_name = convert_encoding(ingredient_name, 
                dictionary_of_html_encoding)
            ingredient_name = ingredient_name.lower()
            ignore_it = False
            for ignore in INGREDIENTS_TO_IGNORE:
                if ingredient_name.find(ignore) != -1:
                    ignore_it = True
                    break
            if not ignore_it:
                recipe_ingredients.add(ingredient_name)
    return list(recipe_ingredients)

def extract_title_and_rating(soup):
    '''
    Helper function for index_one_recipe_page().
    Takes in a BeautifulSoup object and returns the title 
    and rating of the recipe.
    '''
    header_details = soup.find('header')
    title = header_details.find('h1').text
    rating_messy = header_details.find('div', class_ ="fd-rating").text
    rating = rating_messy.strip()[:4]
    return title, rating

def extract_time(recipe_details):
    '''
    Helper function for index_one_recipe_page().
    Takes in a BeautifulSoup object and returns a list containing the
    prep and cook time of the recipe in mins.
    '''
    time_list = []
    time_details = recipe_details.find('div', class_ = 'time-details')
    for tag in time_details.find_all(class_ = 'title'):
        time_list.append(tag.get_text().strip())
    rv = []
    for time in time_list:
        if time.find('min') != -1:
            if time.find('hr') == -1:
                index = time.find('min')
                integer = int(time[4:index].strip())
            else:
                min_index = time.find('min')
                stripped = time[4:min_index].strip()
                hour, minute = stripped.split('hr')
                hour = int(hour.strip())
                minute = int(minute[1:].strip())
                integer = hour*60 + minute
        else:
            index = time.find('hr')
            integer_hrs = int(time[4:index].strip())
            integer = integer_hrs*60
        rv.append(integer)
    return rv

def extract_image(soup):
    '''
    Helper function for index_one_recipe_page().
    Takes in a BeautifulSoup object and returns the image url the recipe.
    '''
    if soup.find('ul', class_ = 'slides') == None:
        entry = soup.find('div', class_ = 'trans-img inner-wrapper')
        #Some recipes have no pictures
        #We return a picture of a troll face if so
        if entry == None:
            return 'http://vignette1.wikia.nocookie.net/creepypasta/images/6/6f/IM-A-TROLL-FACE-PROBLEM.jpg/revision/latest?cb=20110428175443'
        image_details = entry.find('img')
    else:
        ul = soup.find('ul', class_ = 'slides')
        li = ul.find_all('li', class_ = 'slide')
        image_details = None
        for entry in li:
            #Select the cover image.
            if entry['data-slide-position'] == '1':
                image_details = entry.find('img')
    return image_details['data-src']

def index_all_recipe_pages(number_to_index, html_encoding_file):
    '''
    Indexes the specified number of most popular recipe pages on Food.com.
    Outputs 3 json files relating to the dictionaries as described in
    index_one_recipe_page().
    All print statements were printed to a text file for debugging purposes.
    '''
    set_of_recipe_links = find_recipe_links_all_pages(number_to_index)
    dictionary_of_ingredients = {} #{'garlic': {wwww.blah.com}}
    dictionary_of_recipe_links = {} #{'link': [garlic, beef]}
    dictionary_of_details = {} #{'link': {'title': 'Bourbon Chicken', 'image': 'url', 'time': ['Prep 15 mins', 'Cook 20 mins']}}
    dictionary_of_html_encoding = generate_html_encoding_dictionary(html_encoding_file)
    print ('````` BEGIN INDEXING RECIPE PAGES```````')
    for link in set_of_recipe_links:
        index_one_recipe_page(dictionary_of_ingredients, dictionary_of_recipe_links, dictionary_of_details, dictionary_of_html_encoding, link)
    output_to_json_file(dictionary_of_ingredients, DICTIONARY_OF_INGREDIENTS_FILENAME)
    output_to_json_file(dictionary_of_recipe_links, DICTIONARY_OF_RECIPE_LINKS_FILENAME)
    output_to_json_file(dictionary_of_details, DICTIONARY_OF_DETAILS_FILENAME)
    print ('``````DICTIONARY OF INGREDIENTS`````````')
    print (dictionary_of_ingredients)
    print ('``````DICTIONARY OF RECIPE LINKS````````')
    print (dictionary_of_recipe_links)
    print ('````````` ALL INGREDIENTS`````````````')
    for i in dictionary_of_ingredients.keys():
        print(i)



index_all_recipe_pages(NUMBER_OF_PAGES_TO_INDEX, HTML_ENCODING_FILE)